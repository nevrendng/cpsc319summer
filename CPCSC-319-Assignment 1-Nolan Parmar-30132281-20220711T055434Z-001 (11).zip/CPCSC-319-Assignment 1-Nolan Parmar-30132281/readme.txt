To comiple  the file do javac *.java 
Then to run it do java main (number of terms u want)
for exampile if u wanted 20 terms u would do 
java main 20


the array in algorithm 2 is set for 500 so if you want to go over 500 you will have to increase the size of the array 
in algorithm2.java 
