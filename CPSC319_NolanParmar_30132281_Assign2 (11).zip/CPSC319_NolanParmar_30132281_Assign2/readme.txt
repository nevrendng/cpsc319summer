TO compile the program do javac *.java

To run the program do java Assign2 order size sort outputfile

order can be ascending, descending, or random. 
size can be anything greater 0 
sort can be bubble selection insertion merge
outputfile can be any name you want no need to put the .txt